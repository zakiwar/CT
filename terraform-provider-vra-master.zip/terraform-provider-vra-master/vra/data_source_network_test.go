package vra

import (
	"regexp"
	"testing"

	"github.com/hashicorp/terraform-plugin-sdk/helper/acctest"
	"github.com/hashicorp/terraform-plugin-sdk/helper/resource"
)

func TestAccDataSourceVRANetwork(t *testing.T) {
	rInt := acctest.RandInt()
	dataSourceName1 := "data.vra_network.test-network"

	resource.Test(t, resource.TestCase{
		PreCheck:  func() { testAccPreCheckVra(t) },
		Providers: testAccProviders,
		Steps: []resource.TestStep{
			{
				Config:      testAccDataSourceVRANetworkNoneConfig(rInt),
				ExpectError: regexp.MustCompile("network invalid-name not found"),
			},
			{
				Config: testAccDataSourceVRANetworkOneConfig(rInt),
				Check: resource.ComposeTestCheckFunc(
					resource.TestCheckResourceAttr(dataSourceName1, "id", "6d25dcb5d510875582822c89a1d4"),
				),
			},
		},
	})
}

func testAccDataSourceVRANetworkNoneConfig(rInt int) string {
	return `
	    data "vra_network" "test-network" {
			name = "invalid-name"
		}`
}

func testAccDataSourceVRANetworkOneConfig(rInt int) string {
	return `
		data "vra_network" "test-network" {
			name = "foo1-mcm653-56201379059"
		}`
}
